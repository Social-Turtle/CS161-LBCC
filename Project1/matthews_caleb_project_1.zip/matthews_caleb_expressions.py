#find the solution to the equation
problem_a = ((2 ** 4) + 7 - (3+4))/4
#print solution
print("For problem A, let's solve the following:")
print("(2^4 + 7 - (3+4))/4 = X")
print("X equals", problem_a, "\n\n")

#find the solution to the equation
problem_b = (1+(3 ** 2)) * (16%7)/7
#print solution
print("For problem B, let's solve the following:")
print("(1 + 3^2)(16%7)/7 = X")
print("For problem B, X equals", problem_b)