#matthews_caleb_todays_date

#import datetime library
import datetime

#opening date class in datetime module
current_info = datetime.date.today()

#print output for user
print("Today's date is:", current_info)